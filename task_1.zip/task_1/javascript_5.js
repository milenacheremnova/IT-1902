function f()
{
  var a,c;
  a = document.getElementById('r3').value;
  c = a/379.17;
  document.getElementById('r4').value = c.toFixed(2);
}
function f1()
{
  var b,c;
  b = document.getElementById('r3').value;
  c=b/417.32;
  document.getElementById('r4').value = c.toFixed(2);
}
