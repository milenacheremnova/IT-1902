/*
function currency()
{
  let kzt = document.querySelector("#KZT").value;
  let result = 0;
  let currencySelected = document.getElementById("radioUSD").checked;
  if(currencySelected === true)
  {
    result = kzt/380;
  }
  else
  {
    result = kzt/420;
  }
  document.querySelector("#result").value = result.toFixed(2);
}
*/
document.querySelector("#KZT").addEventListener("input",function () {
  let kzt = document.querySelector("#KZT").value
  let usd = kzt/380;
  let euro = kzt/420;
  let pounds = kzt/500;
  document.querySelector("#USD").value = usd.toFixed(2);
  document.querySelector("#EURO").value = euro.toFixed(2);
  document.querySelector("#POUNDS").value = pounds.toFixed(2);
})

document.querySelector("#KZT").addEventListener("change",function () {
  let kzt = document.querySelector("#KZT").value
  let usd = kzt/380;
  let euro = kzt/420;
  let pounds = kzt/500;
  document.querySelector("#USD").value = usd.toFixed(2);
  document.querySelector("#EURO").value = euro.toFixed(2);
  document.querySelector("#POUNDS").value = pounds.toFixed(2);
})
